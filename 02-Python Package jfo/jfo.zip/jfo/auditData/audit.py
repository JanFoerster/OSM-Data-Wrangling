
# coding: utf-8

# In[ ]:

import re
from collections import defaultdict

def check_ZIP(zip_in):
    defect_zip = defaultdict(list)
    zip_type = re.compile(r'^[2]{1}[0-9]{4}$')
    m = zip_type.search(zip_in)
    
    if m is None:
        defect_zip['k'].append(zip_in)
    else:
        print "This is inside %s"  % (m.group())
    
    print defect_zip

